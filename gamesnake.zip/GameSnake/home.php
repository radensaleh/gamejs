<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

	<link rel="icon" type="image/png" href="img/home.png">
	<title>Home</title>

	<!-- Google font -->
	<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700%7CVarela+Round" rel="stylesheet">

	<!-- Flat Admin CSS -->
	<link rel="stylesheet" type="text/css" href="css/flat-admin/vendor.css">
  <link rel="stylesheet" type="text/css" href="css/flat-admin/flat-admin.css">

	<!-- sweetalert2 -->
	<link type="text/css" rel="stylesheet" href="css/sweetalert2.min.css">

	<!-- Bootstrap -->
	<link type="text/css" rel="stylesheet" href="css/bootstrap.min.css" />

	<!-- CDN Font Awesome -->
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.2/css/all.css" integrity="sha384-/rXc/GQVaYpyDdyxK+ecHPVYJSN9bmVFBvjA/9eOB+pb3F2w2N6fc5qB9Ew5yIns" crossorigin="anonymous">

	<!-- Owl Carousel -->
	<link type="text/css" rel="stylesheet" href="css/owl.carousel.css" />
	<link type="text/css" rel="stylesheet" href="css/owl.theme.default.css" />

	<!-- Magnific Popup -->
	<link type="text/css" rel="stylesheet" href="css/magnific-popup.css" />

	<!-- Font Awesome Icon -->
	<link rel="stylesheet" href="css/font-awesome.min.css">

	<!-- Custom stlylesheet -->
	<link type="text/css" rel="stylesheet" href="css/style.css" />

	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
		<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->
</head>

<body>
	<!-- Header -->
	<header id="home">
		<!-- Background Image -->
		<div class="bg-img" style="background-image: url('./img/play-background.jpg');">
			<!-- <div class="overlay"></div> -->
		</div>
		<!-- /Background Image -->

		<!-- Nav -->
		<nav id="nav" class="navbar nav-transparent">
			<div class="container">

				<div class="navbar-header">
					<!-- Logo -->
					<div class="navbar-brand">
						<a href="home.php">
							<img class="logo" src="img/logosnake.png" alt="logo">
							<img class="logo-alt" src="img/logosnake-white.png" alt="logo">
						</a>
					</div>
					<!-- /Logo -->

					<!-- Collapse nav button -->
					<div class="nav-collapse">
						<span></span>
					</div>
					<!-- /Collapse nav button -->
				</div>

				<!--  Main navigation  -->
				<ul class="main-nav nav navbar-nav navbar-right">
					<li><a href="#home">Home</a></li>
					<!-- <li><a href="#about">About</a></li> -->
					<!-- <li><a href="#ss">Screenshot Games</a></li> -->
					<li><a href="#game">Game</a></li>
					<li><a href="#topscore">Top Score Global</a></li>
          <li><a href="#yourscore">Your Score</a></li>
					<!-- <li><a href="#pricing">Prices</a></li> -->
					<!-- <li><a href="#team">Team Developer</a></li> -->
					<!-- <li class="has-dropdown"><a href="#blog">Blog</a>
						<ul class="dropdown">
							<li><a href="blog-single.html">blog post</a></li>
						</ul>
					</li> -->
					<!-- <li><a href="#contact">Contact</a></li> -->
				</ul>
				<!-- /Main navigation -->

			</div>
		</nav>
		<!-- /Nav -->

		<!-- home wrapper -->
		<div class="home-wrapper">
			<div class="container">
				<div class="row">

					<!-- home content -->
					<div class="col-md-10 col-md-offset-1">
						<div class="home-content">
							<h3 class="main-color">Hello <span class="fa fa-user-circle"></span>
								<?php
										session_start();

										if(!isset($_SESSION['username'])){
											header('location:index.php');
										}

										$username = $_SESSION['username'];
										echo $username;

										echo "
													<input type='hidden' id='username' value='$username'/>
										";

								?> !</h3>
							<p class="main-color">Selamat <span class="fa fa-gamepad"></span> Bermain :)</p>
							<button class="btn btn-info" data-toggle="modal" data-target="#myaccount"><span class="fas fa-info-circle"></span> My Account</button>
							<button class="btn btn-danger" id="logout"><span class="fas fa-sign-in-alt"></span> Logout</button>
							<!-- <button class="btn btn-warning" data-toggle="modal" data-target="#about"><span class="fas fa-info-circle"></span> About Us</button> -->
						</div>
					</div>
					<!-- /home content -->

				</div>
			</div>
		</div>
		<!-- /home wrapper -->

	</header>
	<!-- /Header -->

	<!-- Modal myaccount-->
	<div id="myaccount" class="modal fade" role="dialog">
		<div class="modal-dialog">

			<!-- Modal content-->
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h4 class="modal-title"><span class="fas fa-info-circle"></span> My Account</h4>
				</div>
					<div class="modal-body">
						<table class="table table-striped table-bordered table-hover no-footer">
                <tr>
                    <th>Username</th>
                    <td id="iusername"></td>
                </tr>
                <tr>
                    <th>Name</th>
                    <td id="iname"></td>
                </tr>
                <tr>
                    <th>Password</th>
                    <td id="ipassword"></td>
                </tr>
                <tr>
                  <th>Email</th>
                  <td id="iemail"></td>
                </tr>
                <tr>
                  <th>Top Score Snake</th>
                  <td id="topUL1stt">0</td>
                </tr>
            </table>
					</div>
				<div class="modal-footer">
					<a href="editAccount.php" id="btnEdit" class="btn btn-success"><span class="fa fa-cog"></span> Edit Account</a>
					<button type="button" class="btn btn-info" data-dismiss="modal"><span class="fa fa-times-circle"></span> Close</button>
				</div>
			</div>
		</div>
	</div>

	<!-- Modal Snake Game-->
	<div id="snake" class="modal fade" role="dialog">
		<div class="modal-dialog">

			<!-- Modal content-->
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h4 class="modal-title"><i><img src="img/snake1.png" width="30" height="30"></i> Snake</h4>
				</div>
					<div class="modal-body">
						<p>
							<canvas id="canvas" width="542" height="362"></canvas>
							<script>

								var cvs = document.getElementById("canvas"); //inisialisasi canvas
								var ctx = cvs.getContext("2d"); //inisialisasi context 2d

								var img = new Image(); //membuat objek image
								img.src = "img/bg.jpg"; //mengambil source image

								var foodImg = new Image(); //membuat objek image
								foodImg.src = "img/food.png"; //mengambil source image

								// var ling = new Image(); //membuat objek image
								// ling.src = "img/lingkaran.png"; //mengambil source image

								var box = 15; //ukuran kotak ular
								var score = 0; //score
								var newScore = 0;

								var url  = "storeSnake.php";

								var snake = []; //variable snake array
								snake[0] = { //membuat snake index ke 0 berada di x 5 dan y 10
									x : 5 * box ,
									y : 10 * box
								}

								var food = { //variable makanan random
									x : Math.floor(Math.random()*17+1) * box,
									y : Math.floor(Math.random()*15+3) * box
								}

								var d;
								document.addEventListener("keydown", direction); //keydown

								//function untuk mengatur keydown
								function direction(event){
									var key = event.keyCode;
									if( key == 37 && d != "RIGHT" ){
										d = "LEFT";
									}else if( key == 38 && d != "DOWN" ){
										d = "UP";
									}else if( key == 39 && d != "LEFT" ){
										d = "RIGHT";
									}else if( key == 40 && d != "UP" ){
										d = "DOWN";
									}else if( key == 82 ){
											location.reload();
									}
								}

								//function untuk mencetak score
								function printScore(){
									ctx.fillStyle = "white";
									ctx.font = "15px Calibri";
									ctx.fillText("Score : " + score,25,35);
								}

								//function untuk mencetak game over
								function gameOver(){
									clearInterval(game);
									ctx.fillStyle = "white";
									ctx.font = "20px Calibri";
									ctx.fillText("GAME OVER",210,180);

									ctx.fillStyle = "white";
									ctx.font = "12px Calibri";
									ctx.fillText("Reload the page or press 'R' to play again",150,200);
								}

								//function ketika snake menabrak dirinya sendiri
								function collision(head,array){
									for( var i = 0; i < array.length; i++ ){
										if( head.x == array[i].x && head.y == array[i].y ){
											return true;
										}
									} return false;
								}

								//function untuk menggambar keseluruhan
								function draw(){
									ctx.drawImage(img, 13, 13, 530, 362); //gambar background
									for( var i = 0; i < snake.length; i++ ){ //perulangan untuk menggambar snake
											ctx.fillStyle = ( i == 0 )? "#21ff94" : "#e8fff4"; //dengan kepala berwarna biru dan ekor berwarna putih
											ctx.fillRect(snake[i].x, snake[i].y,box,box);

											ctx.strokeStyle = "#21ff94"; //border snake
											ctx.strokeRect(snake[i].x, snake[i].y,box,box);
									}

									ctx.drawImage(foodImg, food.x, food.y, 20, 18); //gambar makanan

									var snakeX = snake[0].x; //variable untuk snakeX
									var snakeY = snake[0].y; //variable untuk snakeY

									if( d == "LEFT" ) snakeX -= box; //keydown left
									if( d == "UP" ) snakeY -= box; //keydown up
									if( d == "RIGHT" ) snakeX += box; //keydown right
									if( d == "DOWN" ) snakeY += box; //keydown down

									if( snakeX == food.x && snakeY == food.y ){ //kondisi jika snake memakan makanan
										score++; //score increment ++
										food = { //gambar makanan secara random
											x : Math.floor(Math.random()*17+1) * box,
											y : Math.floor(Math.random()*15+3) * box
										}
									}else{
											snake.pop(); //snake pop
									}

									var newHead = { //membuat kepala baru
										x : snakeX,
										y : snakeY
									}

									if(snakeX < box || snakeX > 35* box || snakeY < box || snakeY > 23*box
											|| collision(newHead,snake)){ //kondisi ketika snake nabrak dinding dan dirinya sendiri

												var username = document.getElementById("username").value;
												newScore = score;

												$.ajax({
														url:url,
														type:"POST",
														data:{username:username,newScore:newScore},
														dataType:"json",
														success: function(res){
																console.log(res.username);
																console.log(res.newScore);
														}
												});

												gameOver(); //memanggil function gameOver
									}

									snake.unshift(newHead); //snake unshift

									printScore(); //memanggil function printScore

								}

								var game = setInterval(draw, 60); //set interval function draw

							</script>
						</p>
					</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-info" data-dismiss="modal"><span class="fa fa-times-circle"></span> Close</button>
				</div>
			</div>
		</div>
	</div>

	<!-- Modal Readmore Snake Game-->
	<div id="readmore-snake" class="modal fade" role="dialog">
		<div class="modal-dialog">

			<!-- Modal content-->
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h4 class="modal-title"><i><img src="img/snake1.png" width="30" height="30"></i> Snake</h4>
				</div>
					<div class="modal-body">
						<p>
							<b>Snake</b> adalah sebuah video game sederhana yang diciptakan pada akhir tahun 1970 pada arcade. <b>Arcade</b> sendiri adalah platform video game seperti di bioskop-bioskop untuk game tekken. Sejak diciptakannya, kepopularannya terus meningkat dan akhirnya terkenal sebagai game klasik. Lalu sejak dirilis di Handphone Nokia pada tahun 1998, kepopularannya terus meningkat.
						</p>
						<p>
							Si pemain akan mengendalikan sebuah mahluk yang menyerupai ular yang akan bergerak mengitari sebuah bidang berbentuk kotak, dengan tujuan mengambil makanan yang aslinya berbentuk dot atau titik. Selama bermain, si pemain harus berusaha untuk tidak menabrak dinding atau ekornya sendiri dan itu akan semakin susah, karena setiap kali si pemain memakan makanan, ekornya akan bertambah panjang. Kontrol-pun sangat mudah, yakni hanya atas, bawah, kiri dan kanan, ular akan berjalan secara otomatis dan tidak dapat dihentikan.
						</p>
					</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-info" data-dismiss="modal"><span class="fa fa-times-circle"></span> Close</button>
				</div>
			</div>
		</div>
	</div>

	<!-- Snake Game -->
	<div id="game" class="section md-padding">

		<!-- Container -->
		<div class="container">

			<!-- Row -->
			<div class="row">

				<!-- Section header -->
				<!-- <div class="section-header text-center">
					<h2 class="title">Game</h2>
				</div> -->
				<!-- /Section header -->

				<!-- Snake Game -->
				<div class="col-md-12">
					<div class="about">
						<i><img src="img/snake1.png" width="50" height="50"></i>
						<h3>Snake Game</h3>
						<p><b>Snake</b> adalah sebuah video game sederhana yang diciptakan pada akhir tahun 1970 pada arcade.
							 <b>Arcade</b> sendiri adalah platform video game seperti di bioskop-bioskop untuk game tekken. Sejak diciptakannya, kepopularannya terus meningkat dan akhirnya terkenal sebagai game klasik. Lalu sejak dirilis di Handphone Nokia pada tahun 1998, kepopularannya terus meningkat.
						</p>
						<button class="btn btn-danger" data-toggle="modal" data-target="#snake"><span class="fas fa-gamepad"></span> Play Now</button>
						<button class="btn btn-info" data-toggle="modal" data-target="#readmore-snake"><span class="fas fa-info-circle"></span> Readmore</button>
					</div>
				</div>
				<!-- /Snake Game -->

			</div>
			<!-- /Row -->
		</div>
		<!-- /Container -->
	</div>
	<!-- /Snake Game -->

	<!-- Top Score -->
	<div id="topscore" class="section sm-padding">

		<!-- Background Image -->
		<div class="bg-img" style="background-image: url('./img/background2.jpg');">
			<div class="overlay"></div>
		</div>
		<!-- /Background Image -->

		<!-- Container -->
		<div class="container">

			<!-- Row -->
			<div class="row">

				<!-- snake top score -->
				<div class="col-sm-3 col-xs-6">
					<div class="number">
							<i><img src="img/trophy1.png" width="35" height="35"></i>
						<h6 class="white-text"><span class="counter">1st Top Score Global</span></h6>
						<h3 id="topSG1st" class="white-text"><span class="counter">0</span></h3>
						<h6 class="white-text"><span class="counter">Score</span></h6>
						<span id="topUG1st" class="white-text">username</span>
					</div>
				</div>
				<!-- /snake top score -->

				<!-- snake top score -->
				<div class="col-sm-3 col-xs-6">
					<div class="number">
							<i><img src="img/trophy2.png" width="35" height="35"></i>
						<h6 class="white-text"><span class="counter">2nd Top Score Global</span></h6>
						<h3 id="topSG2nd" class="white-text"><span class="counter">0</span></h3>
						<h6 class="white-text"><span class="counter">Score</span></h6>
						<span id="topUG2nd" class="white-text">username</span>
					</div>
				</div>
				<!-- /snake top score -->

				<!-- snake top score -->
				<div class="col-sm-3 col-xs-6">
					<div class="number">
						<i><img src="img/trophy3.png" width="35" height="35"></i>
						<h6 class="white-text"><span class="counter">3rd Top Score Global</span></h6>
						<h3 id="topSG3rd" class="white-text"><span class="counter">0</span></h3>
						<h6 class="white-text"><span class="counter">Score</span></h6>
						<span id="topUG3rd" class="white-text">username</span>
					</div>
				</div>
				<!-- /snake top score -->

				<!-- all player -->
				<div class="col-sm-3 col-xs-6">
					<div class="number">
						<i class="fa fa-user-circle"></i>
						<h6 class="white-text"><span class="counter">All Username</span></h6>
						<h3 id="alluser" class="white-text"><span class="counter">0</span></h3>
						<span class="white-text">Username</span>
					</div>
				</div>
				<!-- /all player -->

			</div>
			<!-- /Row -->

		</div>
		<!-- /Container -->

	</div>
	<!-- /Top Score -->


  <!-- your Score -->
  <div id="yourscore" class="section sm-padding">

    <!-- Background Image -->
    <div class="bg-img" style="background-image: url('./img/background2.jpg');">
      <div class="overlay"></div>
    </div>
    <!-- /Background Image -->

    <!-- Container -->
    <div class="container">

      <!-- Row -->
      <div class="row">

        <!-- snake your score 1st -->
        <div class="col-sm-4 col-xs-6">
          <div class="number">
            <i><img src="img/medal1.png" width="35" height="35"></i>
            <h6 class="white-text"><span class="counter">1st Top Score</span></h6>
            <h3 id="topUL1st" class="white-text"><span class="counter">0</span></h3>
            <h6 class="white-text"><span class="counter">Score</span></h6>
            <!-- <span class="white-text">@rdsaleh</span> -->
          </div>
        </div>
        <!-- /snake your score -->

        <!-- snake your score 2nd -->
        <div class="col-sm-4 col-xs-6">
          <div class="number">
            <i><img src="img/medal2.png" width="35" height="35"></i>
            <h6 class="white-text"><span class="counter">2nd Top Score</span></h6>
            <h3 id="topUL2nd" class="white-text"><span class="counter">0</span></h3>
            <h6 class="white-text"><span class="counter">Score</span></h6>
            <!-- <span class="white-text">@rere</span> -->
          </div>
        </div>
        <!-- /space shooter your score -->


        <!-- snake your score 3rd -->
        <div class="col-sm-4 col-xs-6">
          <div class="number">
            <i><img src="img/medal3.png" width="35" height="35"></i>
            <h6 class="white-text"><span class="counter">3rd Top Score</span></h6>
            <h3 id="topUL3rd" class="white-text"><span class="counter">0</span></h3>
            <h6 class="white-text"><span class="counter">Score</span></h6>
            <!-- <span class="white-text">@harsa</span> -->
          </div>
        </div>
        <!-- /puzzle your score -->

      </div>
      <!-- /Row -->

    </div>
    <!-- /Container -->

  </div>
  <!-- /your Score -->


	<!-- Footer -->
	<footer id="footer" class="sm-padding bg-dark">

		<!-- Container -->
		<div class="container">

			<!-- Row -->
			<div class="row">

				<div class="col-md-12">

					<!-- footer logo -->
					<div class="footer-logo">
						<a href="home.php"><img src="img/logosnake-white.png" alt="logo"></a>
					</div>
					<!-- /footer logo -->

					<!-- footer follow -->
					<ul class="footer-follow">
						<li><a href="#"><i class="fa fa-facebook"></i></a></li>
						<li><a href="#"><i class="fa fa-twitter"></i></a></li>
						<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
						<li><a href="#"><i class="fa fa-instagram"></i></a></li>
						<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
						<li><a href="#"><i class="fa fa-youtube"></i></a></li>
					</ul>
					<!-- /footer follow -->

					<!-- footer copyright -->
					<div class="footer-copyright">
						<p>Copyright © 2018. Kelompok 7 P-WEB . Designed by <a href="https://colorlib.com" target="_blank">Colorlib</a></p>
					</div>
					<!-- /footer copyright -->

				</div>

			</div>
			<!-- /Row -->

		</div>
		<!-- /Container -->

	</footer>
	<!-- /Footer -->

	<!-- Back to top -->
	<div id="back-to-top"></div>
	<!-- /Back to top -->

	<!-- Preloader -->
	<div id="preloader">
		<div class="preloader">
			<span></span>
			<span></span>
			<span></span>
			<span></span>
		</div>
	</div>
	<!-- /Preloader -->

	<!-- jQuery Plugins -->
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<script type="text/javascript" src="js/owl.carousel.min.js"></script>
	<script type="text/javascript" src="js/jquery.magnific-popup.js"></script>
	<script type="text/javascript" src="js/main.js"></script>
	<script type="text/javascript" src="js/sweetalert2.min.js"></script>

	<script type="text/javascript">
			$(document).ready(function (){
					var formRegis = $('#modal-form-register');
					var formLogin = $('#modal-form-login');
          var btnLogout = $('#logout');

					//logout
          btnLogout.click(function() {
            swal({
              title: 'Are you sure?',
              text: "You will logout!",
              type: 'warning',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Logout'
            }).then(OK => {
              if (OK) {
                swal(
                  'Success!',
                  'Logout Success',
                  'success'
                ).then(OK => {
                  if(OK){
										window.location.replace("logout.php");
                  }
                })
              }
            })
          });

					//regis form
					formRegis.submit(function (e) {
						e.preventDefault();

						$.ajax({
								url:formRegis.attr('action'),
								type:formRegis.attr('method'),
								data: formRegis.serialize(),
								dataType: "json",
								success: function( res ){
									if( res.error == 0 ){
										console.log(res);
											$('#register').modal('hide');
											swal(
												'Success',
												res.message,
												'success'
											).then(OK => {
												if(OK){
													location.reload();
												}
											});
									}else{
										$('#register').modal('hide');
										swal(
											'Failed',
											res.message,
											'error'
										).then(OK => {
												if(OK){
													location.reload();
												}
										});
									}
								}
						})
					});

					//login form
					formLogin.submit(function (e) {
						e.preventDefault();

						$.ajax({
								url:formLogin.attr('action'),
								type:formLogin.attr('method'),
								data: formLogin.serialize(),
								dataType: "json",
								success: function( res ){
									if( res.error == 0 ){
										console.log(res);
											$('#login').modal('hide');
											swal(
												'Success',
												res.message,
												'success'
											).then(OK => {
												if(OK){
													location.reload();
												}
											});
									}else{
										$('#login').modal('hide');
										swal(
											'Failed',
											res.message,
											'error'
										).then(OK => {
												if(OK){
													location.reload();
												}
										});
									}
								}
						})
					});

					//get value username
					var username  = document.getElementById("username").value;

					//top score local 1st
					var topUL1st    = document.getElementById("topUL1st");
					var topUL1stt   = document.getElementById("topUL1stt");
					$.ajax({
							url:"topScoreLocal1st.php",
							type:"POST",
							data:{username:username},
							dataType:"json",
							success: function(res){
								topUL1st.innerHTML = res.score;
								topUL1stt.innerHTML = res.score;
							}
					});

					//top score local 2nd
					var topUL2nd    = document.getElementById("topUL2nd");
					$.ajax({
							url:"topScoreLocal2nd.php",
							type:"POST",
							data:{username:username},
							dataType:"json",
							success: function(res){
								topUL2nd.innerHTML = res.score;
								topUL2nd.innerHTML = res.score;
							}
					});

					//top score local 2nd
					var topUL3rd    = document.getElementById("topUL3rd");
					$.ajax({
							url:"topScoreLocal3rd.php",
							type:"POST",
							data:{username:username},
							dataType:"json",
							success: function(res){
								topUL3rd.innerHTML = res.score;
								topUL3rd.innerHTML = res.score;
							}
					});

					//top score global 1st
					var topUG1st = document.getElementById("topUG1st");
					var topSG1st = document.getElementById("topSG1st");
					$.ajax({
							url:"topScoreGlobal1st.php",
							type:"POST",
							data:{},
							dataType:"json",
							success: function(res){
								topUG1st.innerHTML = res.username;
								topSG1st.innerHTML    = res.score;
								// console.log(res);
							}
					});

					//top score global 2nd
					var topUG2nd = document.getElementById("topUG2nd");
					var topSG2nd = document.getElementById("topSG2nd");
					$.ajax({
							url:"topScoreGlobal2nd.php",
							type:"POST",
							data:{},
							dataType:"json",
							success: function(res){
								topUG2nd.innerHTML = res.username;
								topSG2nd.innerHTML    = res.score;
								// console.log(res);
							}
					});

					//top score global 3rd
					var topUG3rd = document.getElementById("topUG3rd");
					var topSG3rd = document.getElementById("topSG3rd");
					$.ajax({
							url:"topScoreGlobal3rd.php",
							type:"POST",
							data:{},
							dataType:"json",
							success: function(res){
								topUG3rd.innerHTML = res.username;
								topSG3rd.innerHTML    = res.score;
								// console.log(res);
							}
					});

					//count all user
					var alluser = document.getElementById("alluser");
					$.ajax({
							url:"alluser.php",
							type:"POST",
							data:{},
							dataType:"json",
							success: function(res){
								alluser.innerHTML = res;
								// console.log(res);
							}
					});

					//myaccount
					var iusername = document.getElementById("iusername");
					var iname     = document.getElementById("iname");
					var iemail    = document.getElementById("iemail");
					var ipassword = document.getElementById("ipassword");
					$.ajax({
							url:"myaccount.php",
							type:"POST",
							data:{username:username},
							dataType:"json",
							success: function(res){
									iusername.innerHTML = res.data.username;
									iname.innerHTML 		= res.data.name_user;
									ipassword.innerHTML = res.data.password;
									iemail.innerHTML 		= res.data.email;
							}
					});

					//edit
					var edit = document.getElementById("btnEdit");

			});
	</script>

</body>

</html>
